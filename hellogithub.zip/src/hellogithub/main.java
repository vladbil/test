package hellogithub;

public class main {

	public static void main(String[] args) {
		String a = "Hello";
// TODO Auto-generated method stub
System.out.println(a  + " Git" );

	}

}
